<?php


session_start(); 
 if (isset($_SESSION['login_user'])) {

include "../views/header.php";

		?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../sweetalert-master/dist/sweetalert.css">

<script src="../sweetalert-master/dist/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../views/css/main.css">
</head>
<body>

<div class="row ">

	<div class="col-md-4 productList_container" >
		<h1>Producten</h1>
		<div onclick="makeNew()">nieuw Product toevoegen</div>
		<div class="productList" id="productList">
			hier komt een lijstje met alle producten
		</div>	
	</div>
		<div class="col-md-8" id="add">
		<h3>Product toevoegen</h3>
		<form action="../model/addproduct.php" method="POST" enctype="multipart/form-data">
		<input type="text" placeholder="title" name="title"  required>
		<input type="text" placeholder="content" name="content" required>		
		<input type="number" placeholder="amount" name="amount" required>
		<input type="text" placeholder="category" name="category" required>
		<input type="text" placeholder="price" name="price" required>
		<input type="text" placeholder="size" name="size" required>
<br><br>
		<input type="file" name="files[]" multiple="multiple" accept="image/*" required>
		<br><br>
		<input type="button" name="annuleren" value="annuleren" onclick="makeNew()">
		<input type="submit" name="toevoegen" value="Toevoegen">
		</form>
	</div>
	<div class="col-md-8" id="edit">
<div id="hi"></div>
	</div>
</div>




</body>
</html>
<script type="text/javascript">
$(document).ready(function () {//1
    productList();
    if(window.location.href.indexOf("update") > -1) {//2
      swal({ //3
    				title: "Uw product is geupdate!",
    				html: true,
    				timer:1250
				});//3
    }//2

    if(window.location.href.indexOf("new") > -1) {
				swal({ 
    				title: "U heeft een product toegevoegd",
    				html: true,
    				timer:1250
				});
    };
    if(window.location.href.indexOf("first") > -1) {
				swal({ 
    				title: "Welkom <?php echo $_SESSION['login_user']?>!",
    				html: true,
    				timer:1250
				});
	};
});//1


function deleteProduct(productid){
    console.log(productid);
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                  console.log(productid + "het heeft gevist");
                  productList();
            }
        };
        xhttp.open("GET", "../model/delete.php?id=" + productid, true);
        xhttp.send();
    // var clicked = document.getElementById("").click
};

function productList() {

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("productList").innerHTML = xhttp.responseText;
            }
        };
        xhttp.open("GET", "../model/getProduct_names.php", true);
        xhttp.send();
    // var clicked = document.getElementById("").click
};


// 	function clickevent(clicked) {
// 	getData(clicked);
// }
function makeNew() {
			$("#edit").fadeOut(500);
            setTimeout(function(){$("#add").fadeIn(500);}, 500);
}

     function getData(clicked) {

            	
     	 var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                
            	$("#add").fadeOut(500);
            	$("#edit").fadeOut(500);
            	
            	

            setTimeout(function(){$("#edit").fadeIn(500);}, 500);
            var hi = document.getElementById("hi");
            hi.innerHTML = xhttp.responseText;
            }
        };
        xhttp.open("GET", "../model/getProduct_content.php?clicked=" + clicked, true);
        xhttp.send();
        console.log(clicked);
     }
    



</script>

<?php  
}else{
   		header("Location: index.php");
	} ?>