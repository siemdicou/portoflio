-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Gegenereerd op: 11 jan 2017 om 14:13
-- Serverversie: 10.1.13-MariaDB
-- PHP-versie: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jennybakker`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `date` mediumtext NOT NULL,
  `products` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `img` varchar(255) NOT NULL,
  `amount` int(4) NOT NULL,
  `category` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `size` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `products`
--

INSERT INTO `products` (`id`, `title`, `content`, `img`, `amount`, `category`, `price`, `size`) VALUES
(1, 'Juwelry Cards Item', 'Mooi schilderij van de natuur in de westerse polder. Hier ziet u de mooie ijsvogel in zijn natuurlijke habitat. Het lijkt nogal schuw door het bos heen maar dat is alleen om zichzelf te verschuilen van zijn natuurlijke vijanden. Het schilderij bevat mooie kleuren van groen en blauw die uw huis echt tot leven laten komen.', 'ijsvogel.jpg', 4, 'jewelry cards', 25, '24 x 123'),
(5, 'Polder', 'De polder is erg nat tijdens dit seizoen. De polder is erg authentiek aan de nederlandse geschiedenis.Nergens anders in de wereld zal je net zoveel polders zien in dit land als elk ander land in de wereld.', 'polder.jpg', 2, 'cadeaus', 45, '45 bij 20 c1'),
(47, 'beer', 'beer is groot', '20170109165347_chipmunk.jpg', 55, 'dier', 45, '40 bij 30 cm'),
(50, 'Workshop item', '2323', '20170109170156_DSC09811.JPG', 233232, 'workshops', 0, 'sadsda'),
(51, 'Books', '2323', '20170109170413_DSC09811.JPG', 233232, 'books', 0, 'sadsda'),
(52, 'Jewelry item', '2323', '20170111074444_', 233232, 'jewelry', 0, 'sadsda'),
(53, 'Workshop item', '2323', '20170109170413_DSC09811.JPG', 233232, 'workshops', 0, 'sadsda'),
(55, 'Lifestyle item', '0', '20170111101558_binnenzijde def.jpeg', 0, 'lifestyle', 0, '0');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sfeerfotos`
--

CREATE TABLE `sfeerfotos` (
  `id` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `sfeerfotos`
--

INSERT INTO `sfeerfotos` (`id`, `img`, `category`) VALUES
(1, '20170111101558_binnenzijde def.jpeg', 'books');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `sfeerfotos`
--
ALTER TABLE `sfeerfotos`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT voor een tabel `sfeerfotos`
--
ALTER TABLE `sfeerfotos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
