<?php 
session_start(); 
include "../config/config.php";

$title	 	= htmlentities($_POST['title']); 
$content 	= htmlentities($_POST['content']);
// $img = $_POST[img upload];
$amount 	= htmlentities($_POST['amount']);
$category 	= htmlentities($_POST['category']);
$price 		= htmlentities($_POST['price']);
$size 		= htmlentities($_POST['size']);
$date = date("YmdHis");

$valid_formats = array("jpg", "png", "gif", "zip", "bmp", "JPG", "jpeg");
$max_file_size = 1024*6000; //100 kb
// $path = "http://www.joeysteffens.com/Jennybakker/uploads/";
$path = "../img/";
 // Upload directory
$count = 0;

var_dump($path);
$profilepicture = $_FILES["files"]["name"][0];


$newfilename = $date."_".$profilepicture;

if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST"){
	// Loop $_FILES to execute all files
	foreach ($_FILES['files']['name'] as $f => $name) {     
	    if ($_FILES['files']['error'][$f] == 4) {
	        continue; // Skip file if any error found
	    }	       
	    if ($_FILES['files']['error'][$f] == 0) {	           
	        if ($_FILES['files']['size'][$f] > $max_file_size) {
	            $message[] = "$name is too large!.";
	            continue; // Skip large files
	        }
			elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) ){
				$message[] = "$name is not a valid format";
				continue; // Skip invalid file formats
			}
	        else{ // No error found! Move uploaded files 

	        	$name_of_file=uniqid().".".$ext;
	            move_uploaded_file($_FILES["files"]["tmp_name"][$f], $path.$newfilename);
	            	$count++; // Number of successfully uploaded files
	            
	        }
	    }
	}
}

$sql = "INSERT INTO products (title,content,amount,category,price,size,img)
VALUES ('$title','$content','$amount','$category','$price','$size', '$newfilename')";
$result = $mysqli->query($sql);

header("Location: ../admin/admin.php#new");
?>