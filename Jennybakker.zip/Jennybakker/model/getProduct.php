<?php 
// session_start();
// var_dump($_SESSION['basket']);
	// require '../config/config.php';


	$result = $mysqli->query( "SELECT * FROM products");
	while($row = $result->fetch_assoc()) {
        	echo'<div class="tile scale-anm all onclick='.$row["category"].'">
        			<a href="Productpage.php?id='.$row['id'].'">
			        <img src="../img/'.$row['img'].'"></a>
			        <h2>'.$row["title"].' </h2>
			        <button onclick="pushArray('.$row["id"].')"><i class="fa fa-2x fa-plus-circle" aria-hidden="true"></i></button></div>
			        ';
			        
}
// <span>'.$row["short"].'</span>'
// 			        <a href="product pagina .php?id='.$row["id"].'"><button type="button">lees meer</button></a>
			        // <button onclick="myAjax('. $row["id"].')">voeg toe</button>
	 		 	 // </div>'

?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript">
function pushArray(id) {
	console.log(id);
      $.ajax({
           type: "POST",
           url: '../model/pushArray.php?id='+ id
      });

 }
</script>

