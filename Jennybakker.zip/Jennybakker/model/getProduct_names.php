<?php

require '../config/config.php';

	$result = $mysqli->query( "SELECT * FROM products");
	while($row = $result->fetch_assoc()) {
        echo '<h3 class="content_title" onclick="getData('. $row["id"] .')">'
        . $row["title"] . '</h3> <i class="fa fa-trash-o" aria-hidden="true" onclick="deleteProduct(' . $row["id"] . ')"></i>';}
		?>