<?php 
	require '../config/config.php'; 
	$result = $mysqli->query( "SELECT * FROM sfeerfotos");
	while($row = $result->fetch_assoc()) {
        	echo'<div class="tile scale-anm all sierf '.$row["category"].'">
			        <img src="img/'.$row['img'].'"></div>
			        ';}
			        echo "<BR>";
 ?>