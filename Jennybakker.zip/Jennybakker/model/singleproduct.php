<?php
require "../config/config.php";
include "../views/header.php";

$productId = $_GET['id'];


$sql = "SELECT * FROM products WHERE id = $productId";
$result = $mysqli->query($sql);
$product = $result->fetch_assoc();


echo $product['content'];
echo '<img src=../img/' . $product['img'] . '>';
echo $product['amount'];
echo $product['category'];
echo $product['price'];
echo $product['size'];


?>