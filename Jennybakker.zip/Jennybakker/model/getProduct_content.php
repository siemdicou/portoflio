<?php 
	require '../config/config.php';
	$clicked = $_GET['clicked'];
	$result = $mysqli->query( "SELECT * FROM products WHERE id= $clicked");

	$row = $result->fetch_assoc();

	echo  '<h3>Product aanpassen</h3>
		<form action="../model/changeproduct.php" method="POST">
		<input type="text" value="'. $row["title"].'" name="title" >
		<input type="text" value="'. $row["content"].'" name="content">
		<!-- <input type="file" value="img upload"> -->

		<input type="text" value="'. $row["amount"].'" name="amount">
		<input type="text" value="'. $row["category"].'" name="category">
		<input type="text" value="'. $row["price"].'" name="price">
		<input type="text" value="'. $row["size"].'" name="size">
		<input type="hidden" name="id" value="'. $row["id"].'">
		<img src="../img/'. $row["img"].'">
			<input type="file" name="files[]" multiple="multiple" accept="image/*">
		<br>
		<Br>
		<input type="button" name="annuleren" value="annuleren" onclick="makeNew()"> 
		<input type="submit" name="toevoegen" value="aanpassen">
		</form>';
?>
