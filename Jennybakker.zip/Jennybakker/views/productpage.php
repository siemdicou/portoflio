<?php
include "../model/singleproduct.php";

echo "Het werkt";

?>