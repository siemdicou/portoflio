<?php include "header.php"; ?>

<body>
    <section class="main-header" style="height:100vh;">

         <div class="producten">        

             
             

         <h1> Uitgelicht</h1>

         <div class="row">
  <div class="col-12 col-md-auto">
      <div class="headerfoto">

      </div>
    </div>
    </div>
    </div>

             
             
             
             
             
             
     
 
             
             
             
             
             
             
             
             
  


    </section>

    

        
 
        
        
        
        

    
    
    
    
    
    
    
    
    
    
    
    
   <?php include "footer.php"; ?>