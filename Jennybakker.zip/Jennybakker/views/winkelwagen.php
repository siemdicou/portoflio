<?php include "header.php";
 ?>

<div class="container padding-top">
    <div class="col-md-7">
    <div id="userProducts"></div>
    </div>
    <div class="col-md-5">

    <form method="POST" action="../webshop/index.php">
<div class="wrap">
  <div class="mat-div">
    <label for="first-name" class="mat-label">First Name</label>
    <input type="text" name="name" class="mat-input" id="first-name" required>
  </div>  
    <div class="mat-div">
    <label for="first-name" class="mat-label">Last Name</label>
    <input type="text" name="lastname" class="mat-input" id="last-name" required>
  </div>

    <div class="mat-div">
    <label for="email" class="mat-label">E-mail</label>
    <input type="email" name="email" class="mat-input" id="email" required>
  </div>

    <div class="mat-div">
    <label for="tel" class="mat-label">Phone Number</label>
    <input type="tel" class="mat-input" name="mobile" id="email" required>
  </div>

    <div class="mat-div">
    <label for="street" class="mat-label">Street</label>
    <input type="text" name="street" class="mat-input" id="street" required>
  </div>

    <div class="mat-div">
    <label for="street" class="mat-label">Street number</label>
    <input type="number" name="number" class="mat-input" id="street" required>
  </div>

      <div class="mat-div">
    <label for="add" class="mat-label">Additional info</label>
    <input type="text" name="add" class="mat-input" id="add" required>
  </div>

        <div class="mat-div">
    <label for="zip" class="mat-label">Postcode</label>
    <input type="text" name="zip" class="mat-input" id="zip" required>
  </div>

  <input type="hidden" name="price" id="total" value="">

    <!-- <input type="submit" name=""> -->
    <button>Submit</button>
</div>
    </form>

    </div>
</div>


<!--aangeven hoeveel er nog beschibaar zijn -->
<!-- komt het lijstje van producten in $user-id mantje -->


<!-- 
<br><br>
<br><br>
<br><br> -->




<!-- <button onclick="whywouldyoudothis()">sadsad</button> -->
<script type="text/javascript">

window.addEventListener("load", getItems);


  function delCart(delClicked){
// console.log(delClicked);

     var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                console.log(xhttp.responseText);
                getItems();
            }
        };
        xhttp.open("GET", "../model/deleteCart.php?delClicked=" + delClicked, true);
        xhttp.send();
}

function getItems() {
// console.log("test3");
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("userProducts").innerHTML = xhttp.responseText;
                var cashHtml = document.getElementById('cash').innerHTML;
                // console.log(cashHtml);
                document.getElementById('total').value = cashHtml;
            }
        };
        xhttp.open("GET", "../model/getShoppingcart.php", true);
        xhttp.send();
    // var clicked = document.getElementById("").click
};
// var hi = document.getElementById("hi");
// hi.addEventListener("click", delCart);


</script>
  <?php include "footer.php"; ?>