<?php include "header.php"; ?>

<body>
  

       
    <section class="main-header overjennysection" style="height:100vh;">
          <div class="container">
			  <div class="overjennysection">
         <div class="row">
			  
     <div class="col-sm-6"> 
    
         
         
         <img id="fotodeel" src="img/fotodeel.png">
         
    </div>
         
         
         <div class="col-sm-6">
    
            <div class="wrap"> <h2 class="naam"> Wie ik ben </h2></div>
			 <p>Ik ben Jenny Bakker en ben geboren in 1966 te Apeldoorn. Mijn ouders hadden op dat moment een boekwinkel 
en al een ander kind; mijn broer. Ik heb twee zonen; Sil van 11 en Jip van 8. We hebben 1 hond die Pablo heet. 
Ik woon de ene helft van de week in Apeldoorn en de andere helft in Amsterdam.
Als kind was ik gek op lezen en was dan ook dolblij met de winkel van mijn ouders.</p>
    
    </div>
        
		</div> 
			  </div>
		<div class="row">
		        
          
     <div class="col-sm-6"> 
    
         
        <div class="wrap"> <h2 class="naam">Wat ik doe</h2></div>
         
         <p> Op de kunstacademie koos ik na enige twijfel tussen mode
en illustratieve vormgeving voor het laatste. 
Na mijn afstuderen heb ik echter jarenlang zelfstandig gewerkt
als grafisch ontwerpster. Langzaam merkte ik dat ik het illustreren
begon te missen en stopte ik met dat vak. 
Mijn werk is inmiddels gepubliceerd bij Clavis, Leopold, Van Goor,
Pimento, Zwijsen, Uitgeverij Holland en nog vele anderen
en verscheen ook in het buitenland, o.a. in China, Amerika, Denemarken en Spanje.</p>
         
    </div>
         
         
         <div class="col-sm-6">
    
             <img id="fotodeel" src="img/sieraden.jpeg">
    
    </div>
        
			</div>
			  </div>   
	</section>

    <section class="main-header" style="height:100vh; background:">

    </section>

   <?php include "footer.php"; ?>
