<?php include "header.php"; ?>

<body>
    <section class="main-header" style="height:100vh;">

         <div class="producten">        

             
             
   
             
             
                  <div class="row">
                        <div class="col-sm-12">
                    <div class="witruimte"></div></div>
  <div class="col-sm-6">
               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d78232.32863642176!2d5.9097647854825865!3d52.21140387014865!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c7b8284d1487cb%3A0x400de5a8d1e65b0!2sApeldoorn!5e0!3m2!1snl!2snl!4v1484142623495" width="80%" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>       
</div>
  <div class="col-sm-5">
      <div class="forms">        
             
     <form>
   Voornaam:<br>
  <input type="text" name="voornaam"><br>
  Achternaam:<br>
  <input type="text" name="achternaam"><br>
       
           Email<br>
          <input type="text" name="email"><br>
           Vraag/Opmerking<br>
  <input class="vraag" type="text" name="vraag">
         
</form>
                      
                      </div>
    
 
             
             </div>      
             
                      </div>
             
                      </div>     
             
             
  


    </section>

    

        
 
        
        
        
        

    
    
    
    
    
    
    
    
    
    
    
    
   <?php include "footer.php"; ?>